+++
title = "Принципы разработки программного обеспечения"
template = "page.html"
page_template = "pattern-page.html"
+++
